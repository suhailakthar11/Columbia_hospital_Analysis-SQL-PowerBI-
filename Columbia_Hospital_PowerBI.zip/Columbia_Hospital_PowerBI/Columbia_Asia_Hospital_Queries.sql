/* ============================================================
   COLUMBIA ASIA HOSPITAL - SQL ANALYSIS FILE
   Prepared by: Ankit Gautam, Consultant Data Analyst
   Tables: Hospital_ER (9,216 rows), Doctor_Patients_data (9,216 rows)
   Join key: patient_id (+ department_referral for department-level joins)
   Dialect: MySQL 8.0+ (CTEs and window functions require 8.0)
   ============================================================ */


/* ============================================================
   OBJECTIVE QUESTION 15
   Identify the top 5 doctors who generated the most revenue
   but had the fewest patients (i.e., highest revenue efficiency).
   ============================================================ */
SELECT
    `Doctor Name`,
    SUM(`Total Bill`)                                          AS total_revenue,
    COUNT(DISTINCT patient_id)                                 AS patient_count,
    ROUND(SUM(`Total Bill`) * 1.0 / COUNT(DISTINCT patient_id), 2) AS revenue_per_patient
FROM Doctor_Patients_data
GROUP BY `Doctor Name`
ORDER BY revenue_per_patient DESC
LIMIT 5;

/* INSIGHT: Dr. White (Rs 3,78,400/patient), Dr. Martin (Rs 3,77,658),
   Dr. Harris (Rs 3,75,805), Dr. Anderson (Rs 2,78,229) and Dr. Thomas
   (Rs 2,75,251) generate exceptionally high revenue per patient despite
   low caseloads (53-85 patients each) - likely high-value specialists
   whose capacity could be expanded without a volume constraint. */


/* ============================================================
   OBJECTIVE QUESTION 16
   Find the department where the average waiting time has
   decreased over three consecutive months.
   ============================================================ */
WITH monthly AS (
    SELECT department_referral,
           DATE_FORMAT(STR_TO_DATE(`date`, '%d-%m-%Y %H:%i'), '%Y-%m-01') AS visit_month,
           AVG(patient_waittime) AS avg_wait
    FROM Hospital_ER
    GROUP BY department_referral, visit_month
),
ranked AS (
    SELECT *,
           LAG(avg_wait, 1) OVER (PARTITION BY department_referral ORDER BY visit_month) AS prev_month,
           LAG(avg_wait, 2) OVER (PARTITION BY department_referral ORDER BY visit_month) AS prev_2month
    FROM monthly
)
SELECT department_referral, visit_month, prev_2month, prev_month, avg_wait
FROM ranked
WHERE prev_2month > prev_month AND prev_month > avg_wait
ORDER BY department_referral, visit_month;

/* INSIGHT: Every department shows at least one 3-month declining streak
   somewhere in the 19-month window - wait times fluctuate rather than
   trend in one direction. Cardiology's Sep-2019 streak is the sharpest:
   46.3 -> 36.3 -> 27.4 minutes, a ~19-minute drop over three months. */


/* ============================================================
   OBJECTIVE QUESTION 17
   Determine the ratio of male to female patients for each doctor
   and rank the doctors based on this ratio.
   ============================================================ */
WITH gender_counts AS (
    SELECT d.`Doctor Name`,
           SUM(CASE WHEN e.patient_gender = 'M' THEN 1 ELSE 0 END) AS male_count,
           SUM(CASE WHEN e.patient_gender = 'F' THEN 1 ELSE 0 END) AS female_count
    FROM Doctor_Patients_data d
    JOIN Hospital_ER e ON d.patient_id = e.patient_id
    GROUP BY d.`Doctor Name`
)
SELECT `Doctor Name`, male_count, female_count,
       ROUND(male_count * 1.0 / NULLIF(female_count, 0), 2) AS male_female_ratio,
       RANK() OVER (ORDER BY male_count * 1.0 / NULLIF(female_count, 0) DESC) AS rnk
FROM gender_counts
ORDER BY rnk;

/* INSIGHT: Widest ratio is Dr. Anderson at 1.35 - no doctor deviates far
   from parity. Patient gender distribution across doctors is essentially
   balanced hospital-wide. */


/* ============================================================
   OBJECTIVE QUESTION 18
   Calculate the average satisfaction score of patients for each
   doctor based on their visits.
   ============================================================ */
SELECT d.`Doctor Name`,
       ROUND(AVG(e.patient_sat_score), 2) AS avg_satisfaction,
       COUNT(e.patient_sat_score)         AS scored_visits
FROM Doctor_Patients_data d
JOIN Hospital_ER e ON d.patient_id = e.patient_id
GROUP BY d.`Doctor Name`
ORDER BY avg_satisfaction DESC;

/* INSIGHT: Highest - Dr. Taylor (7.12, n=17). Lowest - Dr. Robinson
   (3.78, n=9). CAUTION: several doctors have very small scored-visit
   samples (n<20) given the dataset's 72.7% null rate on satisfaction -
   flag these as statistically unreliable rather than true low performers. */


/* ============================================================
   OBJECTIVE QUESTION 19
   Find doctors who have treated patients from different races
   and calculate the diversity of their patient base.
   ============================================================ */
SELECT d.`Doctor Name`,
       COUNT(DISTINCT e.patient_race) AS race_diversity_count
FROM Doctor_Patients_data d
JOIN Hospital_ER e ON d.patient_id = e.patient_id
GROUP BY d.`Doctor Name`
ORDER BY race_diversity_count DESC;

/* INSIGHT: 18 of 22 doctors treated patients across all 7 recorded race
   categories - diversity of patient base is high hospital-wide. Only the
   lowest-volume doctors (Dr. Surya: 4, Dr. Rodriguez: 5, Dr. Clark: 6,
   Dr. Robinson: 6) show narrower diversity, tracking directly with their
   small patient counts rather than any selection pattern. */


/* ============================================================
   OBJECTIVE QUESTION 20
   Calculate the ratio of total bills generated by male patients
   to female patients for each department.
   ============================================================ */
WITH bills AS (
    SELECT d.department_referral,
           SUM(CASE WHEN e.patient_gender = 'M' THEN d.`Total Bill` ELSE 0 END) AS male_bill,
           SUM(CASE WHEN e.patient_gender = 'F' THEN d.`Total Bill` ELSE 0 END) AS female_bill
    FROM Doctor_Patients_data d
    JOIN Hospital_ER e ON d.patient_id = e.patient_id
    GROUP BY d.department_referral
)
SELECT department_referral, male_bill, female_bill,
       ROUND(male_bill * 1.0 / NULLIF(female_bill, 0), 3) AS male_female_bill_ratio
FROM bills
ORDER BY male_female_bill_ratio DESC;

/* INSIGHT: Ranges from Orthopedics (1.19 - men billed ~19% more) to
   Gastroenterology (0.75 - women billed ~33% more). Differences track
   procedure mix per department more than any billing bias. */


/* ============================================================
   OBJECTIVE QUESTION 21
   Update the patient satisfaction score for all patients who
   visited "General Practice" and had a waiting time of more than
   30 minutes. Increase their score by 2 points, capped at 10.
   ============================================================ */
-- Run inside a transaction so it can be rolled back; MySQL safe-update mode may need SET SQL_SAFE_UPDATES = 0;
START TRANSACTION;
UPDATE Hospital_ER
SET patient_sat_score = LEAST(patient_sat_score + 2, 10)
WHERE department_referral = 'General Practice'
  AND patient_waittime > 30;
-- Check the row count (expected 4,296), then COMMIT; or ROLLBACK;

/* INSIGHT: 4,296 rows affected. Verified LEAST() correctly caps the
   result - e.g. a score of 9 becomes 10 (not 11), a score of 1 becomes 3.
   In engines without LEAST(), use: CASE WHEN patient_sat_score + 2 > 10
   THEN 10 ELSE patient_sat_score + 2 END. */


/* ============================================================
   SUPPLEMENTARY - LEVEL 2: JOIN TYPES & WILDCARD/NULL HANDLING
   Confirms every ER visit has a matching billing record.
   ============================================================ */
SELECT e.patient_id, e.department_referral, d.`Total Bill`
FROM Hospital_ER e
LEFT JOIN Doctor_Patients_data d
    ON e.patient_id = d.patient_id AND e.department_referral = d.department_referral
WHERE d.patient_id IS NULL;

/* INSIGHT: 0 rows returned - every one of the 9,216 ER visits joins
   cleanly to a billing record in Doctor_Patients_data. The two source
   files can be treated as a single unified dataset with confidence. */


/* ============================================================
   SUPPLEMENTARY - LEVEL 3: HAVING CLAUSE
   Departments whose average wait time exceeds the hospital-wide
   average (35.26 minutes).
   ============================================================ */
SELECT department_referral,
       ROUND(AVG(patient_waittime), 2) AS avg_wait,
       COUNT(*) AS visits
FROM Hospital_ER
GROUP BY department_referral
HAVING AVG(patient_waittime) > (SELECT AVG(patient_waittime) FROM Hospital_ER)
ORDER BY avg_wait DESC;

/* INSIGHT: Four departments exceed the hospital-wide average of 35.26 min:
   Neurology (36.80), Physiotherapy (36.57), Gastroenterology (35.83) and
   Cardiology (35.35). General Practice (35.20), Orthopedics (34.98) and
   Renal (34.70) are at or below it. (The earlier version hardcoded 35,
   which wrongly included General Practice.) */


/* ============================================================
   SUPPLEMENTARY - LEVEL 3: STRING FUNCTIONS
   Building a clean, display-ready patient name from raw fields.
   ============================================================ */
SELECT patient_id,
       UPPER(TRIM(patient_last_name))                       AS last_name_clean,
       CONCAT(patient_first_inital, '. ', patient_last_name) AS patient_display_name
FROM Hospital_ER
LIMIT 5;

/* INSIGHT: Demonstrates CONCAT, UPPER, and TRIM together to produce a
   presentation-ready name field (e.g. "H. Glasspool") for use in the
   Patients' tab of the Power BI report. */


/* ============================================================
   SUPPLEMENTARY - LEVEL 4: VIEW
   Reusable department-level summary for repeated reporting use.
   ============================================================ */
CREATE VIEW department_summary AS
SELECT department_referral,
       COUNT(*)                          AS total_visits,
       ROUND(AVG(patient_waittime), 2)   AS avg_wait
FROM Hospital_ER
GROUP BY department_referral;

SELECT * FROM department_summary ORDER BY total_visits DESC;

/* INSIGHT: General Practice leads on volume (7,240 visits, 35.20 min
   avg wait) down to Renal (86 visits, 34.70 min avg wait). Wrapping this
   in a VIEW means any future query or report can reference
   department_summary directly instead of repeating the GROUP BY logic. */


/* ============================================================
   SUPPLEMENTARY - LEVEL 9: DML vs DDL CONCEPTS
   ============================================================ */

-- DDL example: changing table STRUCTURE (adding a column)
-- ALTER TABLE Hospital_ER ADD COLUMN age_group VARCHAR(10);

-- DML example: changing VALUES inside existing rows (same pattern as Q21)
-- UPDATE Hospital_ER SET patient_sat_score = 10 WHERE patient_sat_score > 10;

/* NOTES:
   - DELETE (DML) removes rows one at a time, supports WHERE, is logged
     and rollback-able, and fires triggers.
   - TRUNCATE (DDL) removes ALL rows at once by deallocating data pages,
     cannot be filtered with WHERE, is faster, and is typically not
     rollback-able in most engines.
   - ALTER TABLE (DDL) changes a table's STRUCTURE (add/drop/modify a
     column or data type).
   - UPDATE (DML) changes VALUES inside existing rows; structure is
     untouched. */
